# app-deezer
This is mobile apps class excercise. Native aplication on Android, using Java languaje and SDK of Deezer. 
